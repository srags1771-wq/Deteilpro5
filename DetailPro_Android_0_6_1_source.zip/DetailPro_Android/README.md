# DetailPro Android 0.6.1

Android WebView app packaging the interactive DetailPro interface as an offline app.

## Included
- Car selection catalog (current prototype's catalog)
- Exterior/body and interior zone diagrams; tappable areas
- Per-zone contamination level, price/time estimate, optional services
- Client request form and staff order status board
- Local price editor
- Browser local storage persists inside this app installation

## Important limits
- The diagrams are schematic, not manufacturer CAD drawings and not model-specific.
- Data are stored locally on one device. There is no server, account system, or cross-device synchronization.
- Prices are demo values until replaced by the business owner.
- The debug APK is not yet built in this environment because Android SDK/build tools are unavailable and outbound network access is disabled.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder to its root.
2. Open **Actions** and enable workflows if prompted.
3. Run **Build DetailPro APK** using **Run workflow**, or push to `main`/`master`.
4. Open the completed workflow run and download the `DetailPro-debug-APK` artifact. Extract `app-debug.apk` and install it on Android (allow installs from that source if Android asks).

The workflow uses Gradle 8.9, Java 17, Android Gradle Plugin 8.7.3 and compile SDK 35.


## DetailPro 0.6.0
- Added the provided body/interior zone reference image to the app as a responsive reference section.
- The image is informational only; interactive selection and pricing continue to use the existing selectable diagram and zone list.
- Android versionCode incremented to 5; versionName set to 0.6.0.


## DetailPro 0.6.1
- Android 15+: содержимое больше не уходит под строку состояния и навигационную панель; клавиатура не перекрывает поля.
- «Экспорт заявок JSON» теперь работает в приложении (системный диалог «Сохранить как»); раньше кнопка ничего не делала.
- Колёса: две позиции (передние / задние), на схеме кликабельны все четыре колеса; убран двойной учёт.
- Данные заявок экранируются при выводе; стоимость часа «0» больше не заменяется на 1800.
- Добавлена иконка приложения, внешние ссылки открываются в браузере, а не внутри WebView.
- APK по-прежнему не собирался в этой среде (нет Android SDK и сети) — сборка через GitHub Actions.
